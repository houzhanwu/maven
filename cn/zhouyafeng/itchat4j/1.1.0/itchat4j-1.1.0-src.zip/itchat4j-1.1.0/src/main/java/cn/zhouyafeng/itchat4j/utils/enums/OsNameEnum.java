package cn.zhouyafeng.itchat4j.utils.enums;

/**
 * 系统平台
 * 
 * @author https://github.com/yaphone
 * @date 创建时间：2017年4月8日 下午10:36:28
 * @version 1.0
 *
 */
public enum OsNameEnum {
	WINDOWS, LINUX, DARWIN, MAC, OTHER
}
